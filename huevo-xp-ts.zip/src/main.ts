import "./styles.css";
import { ACTIONS, DEF, HATCH_XP, MASCOTS, STAGES } from "./config";
import { $ } from "./dom";
import { clone, level, load, save, stageIdx } from "./state";
import type { MascotId, State } from "./types";
import { buildActions, floatText, render, say } from "./ui";

let S: State = load();

function gain(n: number): void {
  if (S.phase !== "egg" && S.phase !== "creature") return;
  const oldL = level(S.xp), oldS = stageIdx(S.xp);
  S.xp += n;
  floatText("+" + n);
  const st = $("stage");
  st.classList.remove("wobble");
  void st.offsetWidth; // reinicia la animación
  st.classList.add("wobble");
  if (S.phase === "egg" && S.xp >= HATCH_XP) {
    S.phase = "hatching";
    save(S);
    render(S);
    setTimeout(() => {
      S.phase = "choose";
      save(S);
      render(S);
    }, 1400);
    return;
  }
  save(S);
  render(S);
  if (S.phase === "creature") {
    if (stageIdx(S.xp) > oldS) say("¡Ha evolucionado a " + STAGES[stageIdx(S.xp)].n + "!");
    else if (level(S.xp) > oldL) say("¡Subió al nivel " + level(S.xp) + "!");
  }
}

/* ---------- Eventos ---------- */
$("actions").addEventListener("click", (e) => {
  const b = (e.target as HTMLElement).closest<HTMLButtonElement>(".act");
  if (!b || b.disabled) return;
  const a = ACTIONS[Number(b.dataset.i)];
  gain(a.xp);
  if (a.cd) {
    b.disabled = true;
    const s = document.createElement("span");
    s.className = "cd";
    s.style.animationDuration = a.cd + "ms";
    b.appendChild(s);
    setTimeout(() => {
      b.disabled = false;
      s.remove();
    }, a.cd);
  }
});

$("stage").addEventListener("click", () => gain(2));

$("choose").addEventListener("click", (e) => {
  const t = e.target as HTMLElement;
  const card = t.closest<HTMLElement>("[data-mascot]");
  if (card) {
    const id = card.dataset.mascot as MascotId;
    if (MASCOTS.some((m) => m.id === id)) {
      S.cfg.mascot = id;
      save(S);
      render(S);
    }
    return;
  }
  if (t.id === "go") {
    S.cfg.name = ($<HTMLInputElement>("nm").value || "").trim() || MASCOTS.find((m) => m.id === S.cfg.mascot)?.name || "Huevi";
    S.phase = "creature";
    save(S);
    render(S);
    say("¡Hola, " + S.cfg.name + "! Cada XP que ganes lo hará crecer.");
  }
});

$("choose").addEventListener("input", (e) => {
  const t = e.target as HTMLInputElement;
  if (t.id === "nm") {
    S.cfg.name = t.value;
    save(S);
  }
});

$("reset").addEventListener("click", () => {
  if (confirm("Se borrará tu criatura y tu experiencia. ¿Empezar de nuevo?")) {
    S = clone(DEF);
    save(S);
    render(S);
  }
});

buildActions();
render(S);
