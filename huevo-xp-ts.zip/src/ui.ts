import { ACTIONS, HATCH_XP, MASCOTS, STAGES } from "./config";
import { $ } from "./dom";
import { level, stageIdx } from "./state";
import type { State } from "./types";
import { eggSVG } from "./svg/egg";
import { creatureSVG, mascotPreviewSVG } from "./svg/mascots";

const esc = (s: string): string => s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");

export function render(S: State): void {
  const p = S.phase, xp = S.xp, lv = level(xp), si = stageIdx(xp);
  const st = $("stage");
  st.className = "stage" + (p === "egg" || p === "creature" ? "" : " nopet");
  if (p === "egg" || p === "hatching") st.innerHTML = eggSVG(xp);
  else st.innerHTML = creatureSVG(S.cfg, p === "choose" ? HATCH_XP : xp);
  if (p === "hatching") st.classList.add("shake", "flash");

  $("xpnum").textContent = xp + " XP";
  let pct: number;
  if (p === "egg") {
    $("title").textContent = "Tu huevo";
    $("sub").textContent = `Eclosiona a los ${HATCH_XP} XP`;
    pct = xp / HATCH_XP;
    $("hint").textContent =
      xp < 30 ? "Dale cariño para que crezca." : xp < 60 ? "Han aparecido las primeras grietas." : "Ya casi. Algo se mueve dentro.";
  } else if (p === "hatching" || p === "choose") {
    $("title").textContent = "¡Ha eclosionado!";
    $("sub").textContent = "Elige tu mascota";
    pct = 1;
    $("hint").textContent = "";
  } else {
    $("title").textContent = S.cfg.name || "Tu criatura";
    $("sub").textContent = STAGES[si].n + " · nivel " + lv;
    pct = (xp % 50) / 50;
    const nx = STAGES[si + 1];
    $("hint").textContent = nx ? `Faltan ${nx.min - xp} XP para ser ${nx.n}.` : "Has llegado a la etapa máxima. Sigue creciendo.";
  }
  $("fill").style.width = Math.round(pct * 100) + "%";
  $("barwrap").setAttribute("aria-valuenow", String(Math.round(pct * 100)));
  $("actions").hidden = !(p === "egg" || p === "creature");
  $("choose").hidden = p !== "choose";
  if (p === "choose") renderChoose(S);
}

export function renderChoose(S: State): void {
  const c = S.cfg;
  const cards = MASCOTS.map(
    (m) => `<button class="mcard" data-mascot="${m.id}" data-m="${m.id}" aria-pressed="${c.mascot === m.id}">
      ${mascotPreviewSVG(m.id)}<b>${m.name}</b><small>${m.tagline}</small></button>`
  ).join("");
  $("choose").innerHTML = `<h2>Elige a tu mascota</h2><p>Tu elección será su aspecto para siempre. Irá evolucionando con tu experiencia.</p>
  <div class="mascots">${cards}</div>
  <div class="group"><span>Nombre</span><input type="text" id="nm" maxlength="16" placeholder="Ponle un nombre" value="${esc(c.name)}"></div>
  <button class="go" id="go">Presentar a mi criatura</button>`;
}

export function buildActions(): void {
  $("actions").innerHTML = ACTIONS.map(
    (a, i) => `<button class="act" data-i="${i}"><b>${a.e}</b>${a.l}<br><small>+${a.xp} XP</small></button>`
  ).join("");
}

export function floatText(t: string): void {
  const el = document.createElement("span");
  el.className = "float";
  el.textContent = t;
  el.style.left = 35 + Math.random() * 30 + "%";
  $("stage").appendChild(el);
  setTimeout(() => el.remove(), 900);
}

export function say(t: string): void {
  $("hint").textContent = t;
}
