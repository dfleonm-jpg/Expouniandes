export type Phase = "egg" | "hatching" | "choose" | "creature";
export type MascotId = "azul" | "rojo" | "verde";
/** 0 = pequeño, 1 = mediano, 2 = grande (las tres formas de la imagen de referencia) */
export type Form = 0 | 1 | 2;

export interface Cfg {
  mascot: MascotId;
  name: string;
}

export interface State {
  xp: number;
  phase: Phase;
  cfg: Cfg;
}

export interface Stage {
  n: string;
  min: number;
}

export interface MascotInfo {
  id: MascotId;
  name: string;
  tagline: string;
}

export interface Action {
  e: string;
  l: string;
  xp: number;
  cd: number;
}
