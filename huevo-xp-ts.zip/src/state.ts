import { DEF, KEY, OLD_KEY, STAGES } from "./config";
import type { MascotId, Phase, State } from "./types";

const MASCOT_IDS: MascotId[] = ["azul", "rojo", "verde"];
const PHASES: Phase[] = ["egg", "hatching", "choose", "creature"];

export const clone = <T>(v: T): T => JSON.parse(JSON.stringify(v)) as T;

function sanitize(raw: unknown): State | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Partial<State> & { cfg?: Partial<State["cfg"]> };
  if (typeof r.xp !== "number" || !PHASES.includes(r.phase as Phase)) return null;
  const cfg: Partial<State["cfg"]> = r.cfg ?? {};
  const mascot = MASCOT_IDS.includes(cfg.mascot as MascotId) ? (cfg.mascot as MascotId) : DEF.cfg.mascot;
  const name = typeof cfg.name === "string" ? cfg.name : "";
  let phase = r.phase as Phase;
  if (phase === "hatching") phase = "choose";
  return { xp: r.xp, phase, cfg: { mascot, name } };
}

export function load(): State {
  try {
    const cur = sanitize(JSON.parse(localStorage.getItem(KEY) ?? "null"));
    if (cur) return cur;
    // Migración desde la versión HTML anterior: se conserva el XP y se vuelve a elegir mascota.
    const old = JSON.parse(localStorage.getItem(OLD_KEY) ?? "null") as
      | { xp?: unknown; phase?: string; cfg?: { name?: unknown } }
      | null;
    if (old && typeof old.xp === "number") {
      const s = clone(DEF);
      s.xp = old.xp;
      s.phase = old.phase === "egg" ? "egg" : "choose";
      if (s.phase === "choose" && s.xp < STAGES[0].min) s.xp = STAGES[0].min;
      if (typeof old.cfg?.name === "string") s.cfg.name = old.cfg.name;
      return s;
    }
  } catch {
    /* localStorage no disponible o JSON dañado */
  }
  return clone(DEF);
}

export function save(s: State): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* ignorar */
  }
}

export const stageIdx = (xp: number): number => {
  let k = 0;
  STAGES.forEach((s, i) => {
    if (xp >= s.min) k = i;
  });
  return k;
};

export const level = (xp: number): number => Math.floor(xp / 50) + 1;
