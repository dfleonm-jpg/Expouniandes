import type { Action, MascotInfo, Stage, State } from "./types";

export const KEY = "huevo-xp-v2";
export const OLD_KEY = "huevo-xp-v1";

export const STAGES: Stage[] = [
  { n: "Cría", min: 100 },
  { n: "Joven", min: 300 },
  { n: "Adulto", min: 700 },
  { n: "Legendario", min: 1500 },
];

/** Qué forma dibujar en cada etapa (índice de STAGES -> forma 0, 1 o 2). */
export const STAGE_FORM: (0 | 1 | 2)[] = [0, 1, 2, 2];

export const MASCOTS: MascotInfo[] = [
  { id: "azul", name: "Bluno", tagline: "Tranquilo y fuerte" },
  { id: "rojo", name: "Flamo", tagline: "Valiente y ardiente" },
  { id: "verde", name: "Floro", tagline: "Curioso y alegre" },
];

export const ACTIONS: Action[] = [
  { e: "🤚", l: "Acariciar", xp: 5, cd: 0 },
  { e: "🎾", l: "Jugar", xp: 15, cd: 2000 },
  { e: "🍎", l: "Alimentar", xp: 40, cd: 6000 },
];

export const DEF: State = {
  xp: 0,
  phase: "egg",
  cfg: { mascot: "azul", name: "" },
};

export const HATCH_XP = 100;
