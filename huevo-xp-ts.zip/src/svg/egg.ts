export function eggSVG(xp: number): string {
  const p = Math.min(1, xp / 100);
  const sc = (0.55 + 0.45 * p).toFixed(3);
  const cracks = [
    xp >= 30 ? '<path d="M92 60 L104 80 L94 96 L108 116" />' : "",
    xp >= 60 ? '<path d="M150 120 L132 132 L142 150 L124 166" />' : "",
    xp >= 90 ? '<path d="M44 140 L66 150 L56 172 L80 184 M108 116 L90 140" />' : "",
  ].join("");
  return `<svg viewBox="0 0 200 240" role="img" aria-label="Huevo al ${Math.round(p * 100)} por ciento">
  <defs><linearGradient id="sh" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f6f1ff"/><stop offset="1" stop-color="#cdbdf0"/></linearGradient></defs>
  <g transform="translate(100 226) scale(${sc}) translate(-100 -226)">
    <path d="M100 20C150 20 180 120 180 160C180 205 144 225 100 225C56 225 20 205 20 160C20 120 50 20 100 20Z" fill="url(#sh)" stroke="#8d78c4" stroke-width="3"/>
    <g fill="#7bdcb5" opacity=".8"><circle cx="72" cy="150" r="9"/><circle cx="128" cy="105" r="7"/><circle cx="118" cy="180" r="11"/><circle cx="64" cy="108" r="5"/></g>
    <g fill="none" stroke="#4b3a7a" stroke-width="4" stroke-linecap="round" stroke-linejoin="round">${cracks}</g>
  </g></svg>`;
}
