# Mascotas Expoandes (TypeScript)

Versión en TypeScript + Vite de `huevo-xp.html`.

## Uso
```bash
npm install
npm run dev      # abre http://localhost:5173
npm run build    # genera la carpeta dist/
```

## Estructura
- `src/config.ts`  etapas, acciones, mascotas disponibles
- `src/state.ts`   estado, guardado en localStorage, niveles
- `src/svg/egg.ts` dibujo del huevo
- `src/svg/mascots.ts` los 3 monstruos (azul, rojo, verde) en 3 formas cada uno
- `src/ui.ts`      pintar la pantalla
- `src/main.ts`    lógica y eventos
- `src/styles.css` estilos
